#-------------------------------------------------#
# Title: Module 5_Dictionaries
# Dev:   Jon Ernast
# Date:  2018_04_29
# Desc: Module 5
# Environment: python3
# ChangeLog:
# RRoot, 11/02/2016, Created starting template
# 2018-04-30, JErnast, filling sections
#
#-------------------------------------------------#
'''
### Assignment
1.	Create a text file called Todo.txt containing two columns of data (Task, Priority).
2.	When the program starts, load each row of data from the ToDo.txt text file into a Python dictionary. (The data will be stored like a row in a table.)
### Tip: You can use a for loop to read a single line of text from the file and then place the data into a new dictionary object.
3.  Add the new dictionary “row” into a Python list object (now the data will be managed as a table).
4.	Display the contents of the List to the user.
5.	Allow the user to Add or Remove tasks from the list using numbered choices. Something like this would work: 
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
6.	Save the data from the table into the Todo.txt file when the program exits.
'''

#-------------------------------------------------#
# todo.txt expects format of below two lines
'''
Clean House,low
Pay Bills,high
'''

#-------------------------------------------------#

#-------------------------------
#-- Data --#
# declare variables and constants

# objFileName = An object that represents a file
objFileName = "todo.txt"
# todoTable = A row of data separated into elements of a dictionary {Task,Priority}
todoTable = {"Task":"Priority"}
# todoTablefile = add file elements of a dictionary {Task,Priority}
todoTableadd = {}

#-------------------------------
# Step 1 - Load data from a file
    # When the program starts, load each "row" of data 
    # in "ToDo.txt" into a python Dictionary.
todo_fileopen = open(objFileName, "r")
todo_filelines = todo_fileopen.readlines()
todo_fileopen.close()
for line in todo_filelines:
    if len(line):
        line = line.replace("\n","")
        taskadd,priorityadd = line.split(",")
        todoTable[taskadd] = priorityadd

# Step 2 - Display a menu of choices to the user
while(True):
    print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    # strChoice = Capture the user option selection
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print()#adding a new line

    # Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        #printlines(todoTable)
        for tablepair in todoTable:
            print(tablepair,",",todoTable[tablepair])

    # Step 4 - Add a new item to the list/Table
    elif(strChoice.strip() == '2'):
        tasknew = input("\nWhat TASK should be added?: ")
        prioritynew = input("\nWhat's the PRIORITY?: ")
        todoTable[tasknew] = prioritynew
        todoTableadd[tasknew] = prioritynew
        print(tasknew, "has been added.")

    # Step 5 - Remove an item from the list/Table
    elif(strChoice == '3'):
        taskremove = input("What TASK should be removed?: ")
        if taskremove in todoTable:
            del todoTable[taskremove]
            del todoTableadd[taskremove]
            print("\n", taskremove, "has been removed.")
        else:
           print("\nThat TASK doesn't exist.")

    # Step 6 - Save tasks to the ToDo.txt file
    elif(strChoice == '4'):
        todo_file = open(objFileName, "w")
        for tablepair in todoTable:
            linetowrite = str(tablepair + ", " + todoTable[tablepair] + "\n",)
            todo_file.writelines(linetowrite)
            #Close the file to write to disk.

        print("Writing file.")
        todo_file.close()

    # Step 7 - Exit program
    elif (strChoice == '5'):
        break #and Exit the program
